import numpy as np
import matplotlib.pyplot as plt
from tools import *
from optimization import *

def annealing(num_iterations, cities, T0, alpha, cooling_schedule):
    distances = np.zeros(num_iterations)
    current_itinerary = np.array(range(len(cities)))
    current_length = itinerary_cost(current_itinerary, cities)
    Tcurr = T0
    for step in range(num_iterations):
            current_itinerary, current_length, Tcurr = simulated_annealing_step(cities, current_itinerary, Tcurr, T0, alpha, step, cooling_schedule)
            distances[step] = current_length
    return distances

def run_optimization(runs, num_iterations, cities, T0, alpha, cooling_schedule, cool_name):
    distances_all_steps = np.zeros((runs, num_iterations))
    for i in range(runs):
        distances_all_steps[i]  = annealing(num_iterations, cities, T0, alpha, cooling_schedule)
        print(f'Optimization {i} completed')
    # Save data for each beta
    np.savetxt(f'data/optimization_Ncities={len(cities)}_{cool_name}_alpha={alpha}_runs={num_iterations,}.dat', distances_all_steps, delimiter=',')
    print(f'Batch completed for alpha={alpha}\n')

def cooling_comparisons():
        # We now define the parameters for our optimization
    steps = 1000
    T0 = 100
    alphas = [T0/steps, 100., 0.85, 0.85]
    cooling_schedules = [cooling_linear_m, cooling_logarithmic_m, cooling_exponential_m, cooling_quadratic_m]
    cooling_schedules_names = ['Linear', 'Logarithmic', 'Exponential', 'Quadratic']
    
    # We initalize. Current temp is the initial temp, current itinerary is just the initial order
    Tcurr = T0
    current_itinerary = np.array(range(N))
    current_length = itinerary_cost(current_itinerary, cities)

    plt.figure()
    # We apply the simulated annealing
    for i, cooling_schedule in enumerate(cooling_schedules):
        print(f'Now doing {cooling_schedules_names[i]} cooling schedule')
        distances = np.zeros(steps)
        for step in range(steps):
            current_itinerary, current_length, Tcurr = simulated_annealing_step(cities, current_itinerary, Tcurr, T0, alphas[i], step, cooling_schedule)
            distances[step] = current_length
            if step % 100 == 0:
                print(f'Temperature is now {Tcurr}')
        plt.plot(np.array(range(steps)),distances, label = cooling_schedules_names[i])

        Tcurr = T0
        current_itinerary = np.array(range(N))
        current_length = itinerary_cost(current_itinerary, cities)
    plt.legend()

    plt.show()


if __name__ == '__main__' :
    plt.rcParams.update({'font.size': 14})
    # Create cities
    N = 20
    np.random.seed(42) 
    cities = regular_polygon_vertices(apothem=0.4, num_sides=N, center=(0.5, 0.5))
    np.random.shuffle(cities) 
    slow = 1
    fast = 0
    superfast = 2

    # Cooling 
    schedules = [cooling_exponential_m, cooling_logarithmic_m, cooling_quadratic_m]
    names = ['Exponential', 'Logarithmic', 'Quadratic']
    colorsav = ['red', 'green', 'blue']
    colors = ['lightcoral', 'lightgreen', 'lightblue']
    alphas = [[0.9, 300, 10],[0.99, 50, 0.1],[0.5, 0.5, 0.5]]


    k = 1
    state = superfast

    color = colors[k]
    colorav = colorsav[k]
    cool_schedule = schedules[k]
    cool_name = names[k]
    alpha = alphas[state][k]
 
    # Run parameters
    num_iterations = 5000
    num_images = 200
    initial_temperature = 150

    # Create data
    runs = 100
    T0 = 100
    #run_optimization(runs, num_iterations, cities, T0, alpha, cool_schedule, cool_name)

    #distances_all_steps = np.loadtxt(f'data/optimization_Ncities={len(cities)}_{cool_name}_alpha={alpha}_runs={num_iterations,}.dat', dtype=float, delimiter=',')
    #avg_distance = np.mean(distances_all_steps, axis=0)
    #plt.figure()
    #plt.plot(range(num_iterations), distances_all_steps.T, color=color, alpha=0.7)  # Transpose distances_all_steps
    #plt.plot(range(num_iterations), avg_distance, color=colorav, label='Average')
    #plt.axhline(y=itinerary_cost(range(N), regular_polygon_vertices(apothem=0.4, num_sides=N, center=(0.5, 0.5))), color='k', linestyle='-.', label = 'Optimal solution')
    ## put final distance up to 2 decimals
    #plt.title(f'{cool_name} cooling, $\\alpha={alpha}$, {N} cities,{runs} runs\n Final distance: {avg_distance[-1]:.2f}, Optimal distance: {itinerary_cost(range(N), regular_polygon_vertices(apothem=0.4, num_sides=N, center=(0.5, 0.5))):.2f}')
    #plt.xlabel('Iterations')
    #plt.ylabel('Distance')
    #plt.legend()
    #plt.savefig(f'figures/optimization_Ncities={len(cities)}_{cool_name}_alpha={alpha}_runs={runs}.png')
    #plt.close()

    plt.figure(figsize=(6, 6))
    plt.plot(range(num_iterations), avg_distance_slow, color=colorsav[k], label=fr'Slow $\alpha={alphas[slow][k]}$')
    plt.plot(range(num_iterations), avg_distance_fast, color=colorsav[k], label=fr'Fast $\alpha={alphas[fast][k]}$', linestyle='--')
    plt.axhline(y=itinerary_cost(range(N), regular_polygon_vertices(apothem=0.4, num_sides=N, center=(0.5, 0.5))), color='k', linestyle='-.', label = 'Optimal solution')
    plt.title(f'{cool_name} cooling, {N} cities, {runs} runs')
    plt.xlabel('Iterations')
    plt.ylabel('Distance')
    plt.legend()
    plt.savefig(f'figures/optimization_Ncities={len(cities)}_{cool_name}_alpha={alpha}_runs={runs}_slowfast.png')
    plt.close()

    #
    plt.figure(figsize=(9, 6))
    alphas = [0.95,200,0.3]
    for k in range(3) :
        color = colorsav[k]
        colorav = colorsav[k]
        cool_schedule = schedules[k]
        cool_name = names[k]
        alpha = alphas[k]

        #run_optimization(runs, num_iterations, cities, T0, alpha, cool_schedule, cool_name)
        
        distances_all_steps = np.loadtxt(f'data/optimization_Ncities={len(cities)}_{cool_name}_alpha={alpha}_runs={num_iterations,}.dat', dtype=float, delimiter=',')
        average_distance = np.mean(distances_all_steps, axis=0)
        plt.plot(range(num_iterations), average_distance, color=color, label=cool_name)
    plt.axhline(y=itinerary_cost(range(N), regular_polygon_vertices(apothem=0.4, num_sides=N, center=(0.5, 0.5))), color='k', linestyle='-.', label = 'Optimal solution')
    plt.title(f'Comparison of cooling schedules, {N} cities, {runs} runs')
    plt.xlabel('Iterations')
    plt.ylabel('Distance')
    plt.legend()
    plt.savefig(f'figures/optimization_Ncities={len(cities)}_comparison_alpha={alpha}_runs={runs}.png')
    plt.close()


    #avg_distance = np.mean(distances_all_steps, axis=0)
    #avg_distance = np.mean(distances_all_steps, axis=0)