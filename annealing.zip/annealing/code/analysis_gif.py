import numpy as np
import matplotlib.pyplot as plt
from tools import *
from optimization import *
import imageio
def create_gif(num_images ,cities, num_iterations, T0, cool_schedule, cool_name, cool_rate, color, colorav):# Example usage
    N = len(cities)
    frames = []
    fig, ax = plt.subplots()
    Tcurr = T0
    current_itinerary = np.array(range(N))
    current_length = itinerary_cost(current_itinerary, cities)
    for i in range(num_iterations):
        if i % (num_iterations//num_images) == 0:
            ax.clear()
            ax.scatter(cities[:, 0], cities[:, 1], color = colorav, s = 100, marker = 'o')
            ax.plot(cities[current_itinerary, 0], cities[current_itinerary, 1], color = color, ls = '-')
            ax.text(0.95, 0.95, f"Step: {i}\nT: {'{:.2E}'.format(Tcurr)}\nL={current_length:.2f}",
                    horizontalalignment='right', verticalalignment='top',
                    transform=ax.transAxes, fontsize=10)
            ax.set_title(f"{cool_name} cooling with $\\alpha={cool_rate}$")
            ax.set_xticks([])
            ax.set_yticks([])
            plt.tight_layout()
            fig.canvas.draw()
            frame = np.array(fig.canvas.renderer.buffer_rgba())
            frames.append(frame)

        # Run one iteration of simulated annealing
        current_itinerary, current_length, Tcurr = simulated_annealing_step(cities, current_itinerary, Tcurr, T0, cool_rate, i, cool_schedule)
        print(f'Iteration {i}. Current T={Tcurr}')

    # Save frames as a GIF
    imageio.mimsave(f'figures/polygone_optimization_N={N}_{cool_name}_alpha={cool_rate}.gif', frames, fps=num_images//10)

if __name__ == '__main__' :
    plt.rcParams.update({'font.size': 15})
    # Example usage
    N = 25
    np.random.seed(42) 
    cities = regular_polygon_vertices(apothem=0.4, num_sides=N, center=(0.5, 0.5))
    np.random.shuffle(cities) 
    schedules = [cooling_exponential_m, cooling_logarithmic_m, cooling_quadratic_m]
    names = ['Exponential', 'Logarithmic', 'Quadratic']
    colorsav = ['red', 'green', 'blue']
    colors = ['lightcoral', 'lightgreen', 'lightblue']
    alphas = [0.95, 200, 0.3]
    
    num_iterations = 3000
    num_images = 200
    initial_temperature = 100
    #do it for all k
    for k in range(3):
        color = colors[k]
        colorav = colorsav[k]
        cool_schedule = schedules[k]
        cool_name = names[k]
        cool_rate = alphas[k]
        create_gif(num_images ,cities, num_iterations, initial_temperature, cool_schedule, cool_name, cool_rate, color, colorav)